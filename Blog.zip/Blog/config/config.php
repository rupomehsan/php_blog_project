<?php
define("DB_HOST", "localhost");
define("DB_USER", "mdrupome_blog");
define("DB_PASS", "o]i_F!r0kXAj");
define("DB_NAME", "mdrupome_blogproject");
define("TITLE", "RUPOM EHSAN ");
define("Keyword", "RUPOM EHSAN personal website");

